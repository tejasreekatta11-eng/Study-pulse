/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, type FormEvent } from 'react';
import { Plus, Trash2, CheckCircle2, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Topic {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
}

export default function App() {
  const [topics, setTopics] = useState<Topic[]>([]);
  const [inputValue, setInputValue] = useState('');

  const handleAddTopic = (e: FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newTopic: Topic = {
      id: crypto.randomUUID(),
      text: inputValue.trim(),
      completed: false,
      createdAt: Date.now(),
    };

    setTopics([newTopic, ...topics]);
    setInputValue('');
  };

  const toggleTopic = (id: string) => {
    setTopics(topics.map(topic => 
      topic.id === id ? { ...topic, completed: !topic.completed } : topic
    ));
  };

  const deleteTopic = (id: string) => {
    setTopics(topics.filter(topic => topic.id !== id));
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 selection:bg-indigo-100">
      <div className="max-w-xl mx-auto">
        <header className="mb-10 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-indigo-600 text-white rounded-xl shadow-lg shadow-indigo-200 mb-4">
            <MessageSquare size={24} />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Open Topics</h1>
          <p className="mt-2 text-slate-600">Gather and organize your thoughts or discussion points.</p>
        </header>

        <form 
          id="topic-form"
          onSubmit={handleAddTopic}
          className="flex gap-2 mb-8"
        >
          <div className="relative flex-1">
            <input
              id="topic-input"
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="What's on your mind?..."
              className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all placeholder:text-slate-400"
            />
          </div>
          <button
            id="submit-topic"
            type="submit"
            className="px-6 py-3 bg-indigo-600 text-white font-semibold rounded-xl shadow-md shadow-indigo-100 hover:bg-indigo-700 active:scale-95 transition-all flex items-center gap-2 shrink-0"
          >
            <Plus size={20} />
            Add Topic
          </button>
        </form>

        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {topics.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-12 border-2 border-dashed border-slate-200 rounded-2xl"
              >
                <div className="text-slate-400 mb-2">No topics yet</div>
                <p className="text-sm text-slate-500">Your list is clear. Add a topic above to get started.</p>
              </motion.div>
            ) : (
              topics.map((topic) => (
                <motion.div
                  key={topic.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, x: -20 }}
                  className={`group flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-200 transition-all ${
                    topic.completed ? 'bg-slate-50/50' : ''
                  }`}
                >
                  <button
                    onClick={() => toggleTopic(topic.id)}
                    className={`flex-shrink-0 w-6 h-6 rounded-full border-2 transition-all flex items-center justify-center ${
                      topic.completed 
                        ? 'bg-indigo-500 border-indigo-500 text-white' 
                        : 'border-slate-300 group-hover:border-indigo-400'
                    }`}
                  >
                    {topic.completed && <CheckCircle2 size={14} />}
                  </button>
                  
                  <span className={`flex-1 text-slate-700 transition-all ${
                    topic.completed ? 'line-through text-slate-400' : 'font-medium'
                  }`}>
                    {topic.text}
                  </span>

                  <button
                    onClick={() => deleteTopic(topic.id)}
                    className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50/50 rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                    title="Delete topic"
                  >
                    <Trash2 size={18} />
                  </button>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

